document.addEventListener("DOMContentLoaded", function(event) { 
  //do work
  $("#mailing").click(function(){
   $("#usr-EMAIL").focus();
  });
});
